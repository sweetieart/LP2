﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            double[] mediaAluno = new double[2];
            double mediaGeral = 0;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    string aux = Interaction.InputBox(
                        $"Nota do aluno {i + 1}, na matéria do professor {j + 1}:",
                        "Entrada de Dados",
                        "0");
                    if (aux == "")
                        return;

                    if (!double.TryParse(aux, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Valor inválido. Por favor, insira um número.");
                        j--;
                    }
                    else
                    {
                        mediaAluno[i] += notas[i, j];
                    }
                }
                mediaAluno[i] = (mediaAluno[i] / 3);
            }

            mediaGeral = ((mediaAluno[0] + mediaAluno[1]) / 2);

            lstbxSaida.Items.Add("Média alunos\n");
            lstbxSaida.Items.Add($"——————————————————————————————————————————");
            for (int a = 0; a < 2; a++)
            {
                lstbxSaida.Items.Add($"Aluno {a + 1}: Nota Professor 1: {notas[a, 0]:F2} Nota Professor 2: {notas[a, 1]:F2} Nota Professor 3: {notas[a, 2]:F2} Média: {mediaAluno[a]:F2}");
            }
            lstbxSaida.Items.Add($"——————————————————————————————————————————");
            lstbxSaida.Items.Add($"Média Geral Alunos: {mediaGeral:F2}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxSaida.Items.Clear();
        }
    }
}
