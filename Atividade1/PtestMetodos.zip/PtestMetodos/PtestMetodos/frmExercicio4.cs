﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtestMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int posicao = 0, contador = 0;

            while (posicao < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[posicao]))
                {
                    contador++;
                }
                posicao++;
            }
            MessageBox.Show($"A frase tem {contador} números");
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            if (posicao == 0)
            {
                MessageBox.Show("Não há caracteres em branco na frase");
            }
            else
            {
                MessageBox.Show($"O primeiro caractere em branco está na posição {posicao}");
            }
        }

        private void btnContaLetra_Click(object sender, EventArgs e)
        {
            int contaletra = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaletra++;
                }
            }
            MessageBox.Show($"A frase tem {contaletra} letras");
        }
    }
}
